#!/bin/bash

karakter=$1

grep '$' ls  talalt.txt
