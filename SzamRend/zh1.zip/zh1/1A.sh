#!/bin/bash

szam1="$1"
szam2="$2"

echo "A két szám összege: $(($szam1 + $szam2))"
echo "A két szám szorzata: $(($szam1 * $szam2))"

