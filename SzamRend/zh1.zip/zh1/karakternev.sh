#!/bin/bash

read -p "Adjon meg egy jatekosnevet: " jatekosnev


